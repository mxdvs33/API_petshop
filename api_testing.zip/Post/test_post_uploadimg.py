import requests
import json

# указываем ID питомца, к которому нужно загрузить изображение
pet_id = 112

# указываем путь к изображению .jpg или .png на локальной машине
image_path = r"C:\Users\mxdvs\Downloads\cat4.png"  # используем raw строку для пути

# URL для загрузки изображения
url = f"https://petstore.swagger.io/v2/pet/{pet_id}/uploadImage"

# открываем изображение в бинарном формате
files = {'file': open(image_path, 'rb')}

# отправляем POST запрос с файлом изображения
response = requests.post(url, files=files)

# закрываем файл после отправки
files['file'].close()

if response.status_code == 200:
    # выводим ответ API в формате JSON
    result = response.json()
    print("Ответ от API:")
    print(json.dumps(result, indent=4))  # выводим ответ с отступами для читаемости
else:
    print(f"Ошибка при загрузке изображения: {response.status_code}")
