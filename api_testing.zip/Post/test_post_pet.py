import requests
import json

url = "https://petstore.swagger.io/v2/pet"
headers = {"Content-Type": "application/json"}

# данные нового питомца
data = {
    "id": 0,  # ID можно указать свой/оставить "0" для назначения автоматически
    "category": {  # корректное использование словаря для категории
        "id": 20,  # ID категории
        "name": "12132"  # название категории
    },
    "name": "1213",  # имя питомца
    "photoUrls": [
        "https://example.com/photo123.jpg"  # ссылка на фотографию питомца
    ],
    "tags": [
        {
            "id": 12,  # ID тега, можно оставить 0 или указать реальный ID
            "name": "123"  # название тега
        }
    ],
    "status": "123213"  # статус питомца
}

response = requests.post(url, headers=headers, data=json.dumps(data))

if response.status_code == 200:
    print("Питомец успешно добавлен:")
    # Форматируем JSON в читаемый вид
    print(f"Статус код запроса: {response.status_code}")
    print(json.dumps(response.json(), indent=4))
else:
    print(f"Ошибка при добавлении питомца: {response.status_code}")
