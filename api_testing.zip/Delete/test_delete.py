import requests
import json

url = "https://petstore.swagger.io/v2/pet/invalid_id"  # указываем нужный ID

# добавляем заголовки с api_key для авторизации
headers = {
    "Content-Type": "application/json",
    "api_key": "special-key"  # добавляем API ключ в заголовки
}

# отправляем запрос DELETE с заголовками
response = requests.delete(url, headers=headers)

# выводим статус код запроса
print(f"Статус запроса: {response.status_code}")

# если запрос успешен, выводим ответ в формате JSON
if response.status_code == 200:
    print("Питомец успешно удалён.")
    # выводим ответ от API в JSON формате
    result = response.json()
    print(json.dumps(result, indent=4))
else:
    print(f"Ошибка при удалении питомца: {response.status_code}")
    # если есть ответ от API, выводим его
    if response.content:
        print("Ответ от API:")
        print(json.dumps(response.json(), indent=4))
