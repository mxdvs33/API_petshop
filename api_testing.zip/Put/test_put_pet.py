import requests
import json

url = "https://petstore.swagger.io/v2/pet"
headers = {"Content-Type": "application/json"}

# обновление данных о питомце
data = {
    "id": 1212,  # ID питомца, который нужно обновить
    "category": {
        "id": 23,  # ID категории питомца
        "name": "British Cats"  # название категории питомца
    },
    "name": "Fluffy",  # имя питомца
    "photoUrls": [
        "https://example.com/photo112.jpg"  # ссылка на фотографию питомца
    ],
    "tags": [
        {
            "id": 23,  # ID тега
            "name": "Cat"  # название тега питомца
        }
    ],
    "status": "sold"  # статус питомца
}

response = requests.put(url, headers=headers, data=json.dumps(data))

if response.status_code == 200:
    print("Питомец успешно обновлён:")
    # Выводим код ответа
    print(f"Код ответа на запрос: {response.status_code}")
    # Форматируем JSON в читаемый вид
    print(json.dumps(response.json(), indent=4))
else:
    print(f"Ошибка при обновлении питомца: {response.status_code}")
