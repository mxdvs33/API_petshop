import requests
import json

# подставляем число реального ID питомца, информацию о котором нужно получить
pet_id = 123
url = f"https://petstore.swagger.io/v2/pet/{pet_id}"
headers = {"Content-Type": "application/json"}

response = requests.get(url, headers=headers)

# выводим статус код запроса
print(f"Статус запроса: {response.status_code}")

if response.status_code == 200:
    pet_info = response.json()
    
    # печатаем информацию о питомце, приведённую в нужную структуру
    print("Информация о питомце:")
    print(json.dumps(pet_info, indent=4))
else:
    print(f"Ошибка при получении информации о питомце: {response.status_code}")
